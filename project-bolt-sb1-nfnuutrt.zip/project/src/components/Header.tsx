import { ShoppingBag, MessageCircle } from 'lucide-react';
import { useCart } from '../context/CartContext';

interface HeaderProps {
  onNavigate: (page: string) => void;
  currentPage: string;
}

export const Header = ({ onNavigate, currentPage }: HeaderProps) => {
  const { getTotalItems } = useCart();
  const totalItems = getTotalItems();

  const handleWhatsApp = () => {
    window.open('https://wa.me/33123456789', '_blank');
  };

  return (
    <header className="fixed top-0 left-0 right-0 bg-white/95 backdrop-blur-sm z-50 border-b border-gray-100">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-20">
          <button
            onClick={() => onNavigate('home')}
            className="text-2xl font-light tracking-wider text-gray-900 hover:text-[#E8B4B8] transition-colors"
          >
            Chambre <span className="font-normal">69</span>
          </button>

          <nav className="hidden md:flex items-center space-x-8">
            <button
              onClick={() => onNavigate('home')}
              className={`text-sm tracking-wide transition-colors ${
                currentPage === 'home' ? 'text-[#E8B4B8]' : 'text-gray-700 hover:text-[#E8B4B8]'
              }`}
            >
              Accueil
            </button>
            <button
              onClick={() => onNavigate('shop')}
              className={`text-sm tracking-wide transition-colors ${
                currentPage === 'shop' ? 'text-[#E8B4B8]' : 'text-gray-700 hover:text-[#E8B4B8]'
              }`}
            >
              Boutique
            </button>
            <button
              onClick={() => onNavigate('about')}
              className={`text-sm tracking-wide transition-colors ${
                currentPage === 'about' ? 'text-[#E8B4B8]' : 'text-gray-700 hover:text-[#E8B4B8]'
              }`}
            >
              À propos
            </button>
            <button
              onClick={() => onNavigate('contact')}
              className={`text-sm tracking-wide transition-colors ${
                currentPage === 'contact' ? 'text-[#E8B4B8]' : 'text-gray-700 hover:text-[#E8B4B8]'
              }`}
            >
              Contact
            </button>
          </nav>

          <div className="flex items-center space-x-6">
            <button
              onClick={handleWhatsApp}
              className="text-gray-700 hover:text-[#E8B4B8] transition-colors"
              aria-label="WhatsApp"
            >
              <MessageCircle className="h-6 w-6" />
            </button>
            <button
              onClick={() => onNavigate('cart')}
              className="relative text-gray-700 hover:text-[#E8B4B8] transition-colors"
              aria-label="Panier"
            >
              <ShoppingBag className="h-6 w-6" />
              {totalItems > 0 && (
                <span className="absolute -top-2 -right-2 bg-[#E8B4B8] text-white text-xs rounded-full h-5 w-5 flex items-center justify-center font-medium">
                  {totalItems}
                </span>
              )}
            </button>
          </div>
        </div>

        <nav className="md:hidden flex items-center justify-around py-3 border-t border-gray-100">
          <button
            onClick={() => onNavigate('home')}
            className={`text-xs tracking-wide transition-colors ${
              currentPage === 'home' ? 'text-[#E8B4B8]' : 'text-gray-700'
            }`}
          >
            Accueil
          </button>
          <button
            onClick={() => onNavigate('shop')}
            className={`text-xs tracking-wide transition-colors ${
              currentPage === 'shop' ? 'text-[#E8B4B8]' : 'text-gray-700'
            }`}
          >
            Boutique
          </button>
          <button
            onClick={() => onNavigate('about')}
            className={`text-xs tracking-wide transition-colors ${
              currentPage === 'about' ? 'text-[#E8B4B8]' : 'text-gray-700'
            }`}
          >
            À propos
          </button>
          <button
            onClick={() => onNavigate('contact')}
            className={`text-xs tracking-wide transition-colors ${
              currentPage === 'contact' ? 'text-[#E8B4B8]' : 'text-gray-700'
            }`}
          >
            Contact
          </button>
        </nav>
      </div>
    </header>
  );
};
