import { Instagram, Mail, MessageCircle } from 'lucide-react';

interface FooterProps {
  onNavigate: (page: string) => void;
}

export const Footer = ({ onNavigate }: FooterProps) => {
  return (
    <footer className="bg-[#111111] text-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div>
            <h3 className="text-2xl font-light tracking-wider mb-4">
              Chambre <span className="font-normal">69</span>
            </h3>
            <p className="text-gray-400 text-sm leading-relaxed">
              Lingerie haut de gamme alliant confort, élégance et confiance.
            </p>
          </div>

          <div>
            <h4 className="text-sm font-medium tracking-wide mb-4">Navigation</h4>
            <ul className="space-y-2">
              <li>
                <button
                  onClick={() => onNavigate('home')}
                  className="text-gray-400 hover:text-[#E8B4B8] transition-colors text-sm"
                >
                  Accueil
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigate('shop')}
                  className="text-gray-400 hover:text-[#E8B4B8] transition-colors text-sm"
                >
                  Boutique
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigate('about')}
                  className="text-gray-400 hover:text-[#E8B4B8] transition-colors text-sm"
                >
                  À propos
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigate('contact')}
                  className="text-gray-400 hover:text-[#E8B4B8] transition-colors text-sm"
                >
                  Contact
                </button>
              </li>
            </ul>
          </div>

          <div>
            <h4 className="text-sm font-medium tracking-wide mb-4">Nous contacter</h4>
            <div className="flex space-x-4">
              <a
                href="https://instagram.com"
                target="_blank"
                rel="noopener noreferrer"
                className="text-gray-400 hover:text-[#E8B4B8] transition-colors"
                aria-label="Instagram"
              >
                <Instagram className="h-5 w-5" />
              </a>
              <a
                href="https://wa.me/33123456789"
                target="_blank"
                rel="noopener noreferrer"
                className="text-gray-400 hover:text-[#E8B4B8] transition-colors"
                aria-label="WhatsApp"
              >
                <MessageCircle className="h-5 w-5" />
              </a>
              <a
                href="mailto:contact@chambre69.com"
                className="text-gray-400 hover:text-[#E8B4B8] transition-colors"
                aria-label="Email"
              >
                <Mail className="h-5 w-5" />
              </a>
            </div>
          </div>
        </div>

        <div className="mt-8 pt-8 border-t border-gray-800 text-center">
          <p className="text-gray-400 text-xs">
            &copy; {new Date().getFullYear()} Chambre 69. Tous droits réservés.
          </p>
        </div>
      </div>
    </footer>
  );
};
