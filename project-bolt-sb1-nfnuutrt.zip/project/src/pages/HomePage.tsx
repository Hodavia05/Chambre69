import { useState, useEffect } from 'react';
import { supabase, Category, Product, ProductVariant } from '../lib/supabase';
import { MessageCircle } from 'lucide-react';
import { useCart } from '../context/CartContext';

interface HomePageProps {
  onNavigate: (page: string, data?: any) => void;
}

export const HomePage = ({ onNavigate }: HomePageProps) => {
  const [categories, setCategories] = useState<Category[]>([]);
  const [featuredProducts, setFeaturedProducts] = useState<(Product & { variant: ProductVariant })[]>([]);
  const { addToCart } = useCart();

  useEffect(() => {
    loadCategories();
    loadFeaturedProducts();
  }, []);

  const loadCategories = async () => {
    const { data } = await supabase
      .from('categories')
      .select('*')
      .order('name');
    if (data) setCategories(data);
  };

  const loadFeaturedProducts = async () => {
    const { data: products } = await supabase
      .from('products')
      .select('*')
      .eq('is_featured', true)
      .limit(6);

    if (products) {
      const productsWithVariants = await Promise.all(
        products.map(async (product) => {
          const { data: variants } = await supabase
            .from('product_variants')
            .select('*')
            .eq('product_id', product.id)
            .limit(1)
            .maybeSingle();
          return { ...product, variant: variants! };
        })
      );
      setFeaturedProducts(productsWithVariants);
    }
  };

  const handleAddToCart = (product: Product, variant: ProductVariant) => {
    addToCart(product, variant, variant.sizes[0]);
  };

  return (
    <div className="min-h-screen">
      <section className="relative h-screen flex items-center justify-center bg-gradient-to-br from-[#F9F5F6] to-[#E8B4B8]/20">
        <div
          className="absolute inset-0 z-0"
          style={{
            backgroundImage: 'url(https://images.pexels.com/photos/8129903/pexels-photo-8129903.jpeg?auto=compress&cs=tinysrgb&w=1600)',
            backgroundSize: 'cover',
            backgroundPosition: 'center',
            opacity: 0.15
          }}
        />
        <div className="relative z-10 text-center px-4 max-w-4xl mx-auto">
          <h1 className="text-5xl md:text-7xl font-light tracking-wide text-gray-900 mb-6">
            Révélez votre féminité<br />
            <span className="text-[#E8B4B8]">avec élégance</span>
          </h1>
          <p className="text-lg md:text-xl text-gray-600 mb-8 max-w-2xl mx-auto">
            Découvrez notre collection de lingerie haut de gamme, conçue pour sublimer votre beauté naturelle
          </p>
          <button
            onClick={() => onNavigate('shop')}
            className="bg-[#111111] text-white px-10 py-4 text-sm tracking-wide hover:bg-[#E8B4B8] transition-all duration-300 transform hover:scale-105"
          >
            Découvrir la collection
          </button>
        </div>
      </section>

      <section className="py-20 px-4 bg-white">
        <div className="max-w-7xl mx-auto">
          <h2 className="text-3xl md:text-4xl font-light text-center mb-4 text-gray-900">
            Nos Produits
          </h2>
          <p className="text-center text-gray-600 mb-12 max-w-3xl mx-auto">
            Une large gamme de lingerie et d'articles associés, pensés pour répondre aux besoins essentiels des femmes
          </p>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {categories.map((category) => (
              <button
                key={category.id}
                onClick={() => onNavigate('shop', { categorySlug: category.slug })}
                className="group bg-[#F9F5F6] p-8 hover:bg-[#E8B4B8]/10 transition-all duration-300 text-left"
              >
                <h3 className="text-xl font-medium mb-3 text-gray-900 group-hover:text-[#E8B4B8] transition-colors">
                  {category.name}
                </h3>
                <p className="text-sm text-gray-600 leading-relaxed">
                  {category.description}
                </p>
              </button>
            ))}
          </div>
        </div>
      </section>

      <section className="py-20 px-4 bg-[#F9F5F6]">
        <div className="max-w-7xl mx-auto">
          <h2 className="text-3xl md:text-4xl font-light text-center mb-12 text-gray-900">
            Produits Vedettes
          </h2>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {featuredProducts.map((item) => (
              <div
                key={item.id}
                className="bg-white group cursor-pointer"
              >
                <div
                  className="relative h-96 bg-gray-100 overflow-hidden mb-4"
                  onClick={() => onNavigate('product', { slug: item.slug })}
                >
                  <img
                    src={item.image_url}
                    alt={item.name}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                  />
                </div>
                <div className="p-4">
                  <h3
                    className="text-lg font-medium mb-2 text-gray-900 group-hover:text-[#E8B4B8] transition-colors cursor-pointer"
                    onClick={() => onNavigate('product', { slug: item.slug })}
                  >
                    {item.name}
                  </h3>
                  <p className="text-sm text-gray-600 mb-2">
                    Couleur: {item.variant?.color}
                  </p>
                  <p className="text-sm text-gray-600 mb-3">
                    Tailles: {item.variant?.sizes.join(', ')}
                  </p>
                  <p className="text-sm text-gray-700 mb-4 line-clamp-2">
                    {item.description}
                  </p>
                  <div className="flex gap-2">
                    <button
                      onClick={() => onNavigate('product', { slug: item.slug })}
                      className="flex-1 bg-[#111111] text-white px-4 py-2 text-sm hover:bg-[#E8B4B8] transition-colors"
                    >
                      Voir produit
                    </button>
                    <button
                      onClick={() => handleAddToCart(item, item.variant)}
                      className="flex-1 border border-[#111111] text-[#111111] px-4 py-2 text-sm hover:bg-[#111111] hover:text-white transition-colors"
                    >
                      Ajouter au panier
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="py-32 px-4 bg-[#111111] text-white text-center">
        <div className="max-w-4xl mx-auto">
          <h2 className="text-4xl md:text-5xl font-light mb-6">
            Osez révéler votre côté<br />
            <span className="text-[#E8B4B8]">le plus irrésistible</span>
          </h2>
          <p className="text-gray-300 mb-8 text-lg">
            Découvrez notre collection de pièces sensuelles et sophistiquées
          </p>
          <button
            onClick={() => onNavigate('shop', { categorySlug: 'pieces-sensuelles' })}
            className="bg-[#E8B4B8] text-white px-10 py-4 text-sm tracking-wide hover:bg-white hover:text-[#111111] transition-all duration-300 transform hover:scale-105"
          >
            Découvrir
          </button>
        </div>
      </section>

      <section className="py-20 px-4 bg-white">
        <div className="max-w-5xl mx-auto">
          <h2 className="text-3xl md:text-4xl font-light text-center mb-12 text-gray-900">
            Avis de nos Clientes
          </h2>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="bg-[#F9F5F6] p-8">
              <div className="mb-4">
                <span className="text-[#C9A96E] text-2xl">★★★★★</span>
              </div>
              <p className="text-gray-700 mb-4 italic">
                "Qualité exceptionnelle et confort inégalé. Je recommande vivement!"
              </p>
              <p className="text-sm text-gray-600 font-medium">- Sophie M.</p>
            </div>

            <div className="bg-[#F9F5F6] p-8">
              <div className="mb-4">
                <span className="text-[#C9A96E] text-2xl">★★★★★</span>
              </div>
              <p className="text-gray-700 mb-4 italic">
                "Des pièces élégantes qui subliment vraiment. Service client au top!"
              </p>
              <p className="text-sm text-gray-600 font-medium">- Marie L.</p>
            </div>

            <div className="bg-[#F9F5F6] p-8">
              <div className="mb-4">
                <span className="text-[#C9A96E] text-2xl">★★★★★</span>
              </div>
              <p className="text-gray-700 mb-4 italic">
                "Je me sens tellement confiante et féminine. Merci Chambre 69!"
              </p>
              <p className="text-sm text-gray-600 font-medium">- Léa B.</p>
            </div>
          </div>
        </div>
      </section>

      <section className="py-20 px-4 bg-[#E8B4B8]/10">
        <div className="max-w-4xl mx-auto text-center">
          <MessageCircle className="h-16 w-16 mx-auto mb-6 text-[#E8B4B8]" />
          <h2 className="text-3xl md:text-4xl font-light mb-4 text-gray-900">
            Commandez facilement via WhatsApp
          </h2>
          <p className="text-gray-600 mb-8 text-lg">
            Un service personnalisé et rapide pour toutes vos commandes
          </p>
          <button
            onClick={() => window.open('https://wa.me/33123456789?text=Bonjour, je souhaite passer une commande', '_blank')}
            className="bg-[#25D366] text-white px-10 py-4 text-sm tracking-wide hover:bg-[#20BD5A] transition-all duration-300 transform hover:scale-105 inline-flex items-center gap-2"
          >
            <MessageCircle className="h-5 w-5" />
            Commander maintenant
          </button>
        </div>
      </section>
    </div>
  );
};
